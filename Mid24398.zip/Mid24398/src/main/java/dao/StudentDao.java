package dao;

import model.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentDao {

    public void studentRegister(Student student) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(student);
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
