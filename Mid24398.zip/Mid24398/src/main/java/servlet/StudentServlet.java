package servlet;

import dao.StudentDao;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;
import model.Student;

import java.io.IOException;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Ensure proper character encoding for request parameters
        request.setCharacterEncoding("UTF-8");

        // Retrieve form parameters
        String id = request.getParameter("studentId");
        String fullName = request.getParameter("fullName"); // Update parameter name for full name
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");

        // Create a new Student object
        Student student = new Student();

        // Set the retrieved parameters to the Student object
        student.setId(id);
        student.setFullName(fullName); // Assuming you have setFullName method in Student class
        student.setFirstName(firstName);
        student.setLastName(lastName);

        // Save student information using StudentDao
        StudentDao studentDao = new StudentDao();
        studentDao.studentRegister(student);

        // Redirect to a success page after saving
        response.sendRedirect("index.jsp");
    }

    public void destroy() {
    }
}
